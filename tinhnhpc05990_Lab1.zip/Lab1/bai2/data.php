<?php
$course = [
    's1' => 'course',
    's2' => 'course2',
    's3' => 'course3'
];
?>