<?php
$user = get_user();