<?= (isset($user['name']) ? $user['name'] : '') ?>
<form action="" method="post">
    <input type="text" name="email">
    <input type="submit">
</form>