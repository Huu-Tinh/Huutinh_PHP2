<?php
include './model/model.php';
include './controller/controller.php';
include './view/view.php';
